class Carte:

	def __init__(self,valeur,couleur) :

		# Chaque carte a une couleur, une valeur pratique (As, Roi, etc) et une valeur numerique (1, 2, 3, etc)

		# Liste des couleurs possibles des cartes
		couleurs_possibles = ["Coeur", "Pique", "Carreau", "Trefle"]

		if type(couleur) is int: # Si l'argument est un entier
			self.couleur = couleurs_possibles[couleur%4]
		elif type(couleur) is str: # Si l'argument est une chaine de caracteres
			self.couleur = couleur if couleur in couleurs_possibles else "Coeur"
		else: # Que peut-on faire si la carte a ete mal declaree
			self.couleur = "Trefle"

		# Liste des valeurs possibles des cartes
		valeurs_cartes_dict = {2: "2", 3: "3", 4: "5", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "10", 11: "Valet", 12: "Dame", 13: "Roi", 14: "As"}
		
		if type(valeur) is int: # Si l'argument est un entier
			self.valeur_numerique = valeur if valeur > 1 and valeur < 15 else 14
			self.valeur_pratique = valeurs_cartes_dict[self.valeur_numerique]
		elif type(valeur) is str: # Si l'argument est une chaine de caracteres
			valeurs_cartes_dict_inv = {v: k for k, v in valeurs_cartes_dict.items()}
			self.valeur_pratique = valeur if valeur in valeurs_cartes_dict_inv.keys() else "As"
			self.valeur_numerique = valeurs_cartes_dict_inv[self.valeur_pratique]


	# Pour afficher une carte en chaine de caracteres
	def afficher(self):
		print(self.valeur_pratique+" de "+self.couleur)