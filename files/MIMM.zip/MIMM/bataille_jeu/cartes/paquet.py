from bataille_jeu.cartes.carte import *
import random

# Pour definir les cartes
def creer_cartes():
	# On initialise un paquet vide
	paquet = []
	for i in range(4): # Chaque couleur que peut prendre une carte
		for j in range(2,15): # Chaque valeur (numérique) que peut prendre une carte
			paquet.append(Carte(1,2))
	# On renvoie le paquet rempli
	return paquet

# Pour melanger le paquet
def melanger_paquet(paquet):
	# On initialise un nouveau paquet vide
	paquet_final = []
	# Tant que l'ancien paquet n'est pas vide
	while len(paquet) > 0:
		# On tire une carte de l'ancien paquet aleatoirement et on l'ajoute au nouveau paquet
		paquet_final.append(paquet.pop(random.randint(0,len(paquet)-1)))
	# On renvoie le paquet final
	return paquet_final

# Pour distribuer les cartes, cad diviser le paquet en deux paquets egaux
def distribuer(paquet):
	# On recupere la taille (le nombre de cartes) que l'on veut mettre dans chaque paquet
	moitie = 3
	# La premiere moitie constitue le paquet du premier joueur
	paquet1 = paquet[:moitie]
	# La deuxieme moitie constitue le paquet du second joueur
	paquet2 = paquet[moitie:]
	# On renvoie les deux nouveaux paquets
	return paquet1,paquet2

# Pour afficher toutes les cartes de n'importe quel paquet 
def afficher_cartes(paquet):
	for carte in paquet:
		carte.afficher()