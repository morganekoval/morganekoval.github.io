import bataille_jeu.cartes.paquet as pqt
import pygame
import time

# Temps d'attente (en secondes)
TMP_ATT = 0.3

# Marges
MARGIN_LEFT = 230
MARGIN_TOP = 150

# Taille de la fenetre
WIDTH = 800
HEIGHT = 600

# Couleurs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (110, 110, 110)
GREEN = (0, 255, 0)
LIGHT_GREEN = (0, 120, 0)
RED = (255, 0, 0)
LIGHT_RED = (120, 0, 0)

pygame.init()

# Preparation de l'ecran et du fond
screen = pygame.display.set_mode((WIDTH, HEIGHT))
screen.fill((3,93,12))

# Titre du jeu
pygame.display.set_caption("Jeu de bataille")
 
# Chargement de l'image du jeu
icon = pygame.image.load('./img/cartes/dos.png')
 
# Declaration de l'image du jeu
pygame.display.set_icon(icon)

# Les polices a utiliser
small_font = pygame.font.Font(None, 32)
large_font = pygame.font.Font(None, 50)

# Affichage des deux paquets des joueurs
dos = pygame.image.load('./img/cartes/dos.png')
dos = pygame.transform.scale(dos , (100,160))
screen.blit(dos, (MARGIN_LEFT-105,MARGIN_TOP))
screen.blit(dos, (MARGIN_LEFT-100,MARGIN_TOP))
screen.blit(dos, (MARGIN_LEFT+340,MARGIN_TOP))
screen.blit(dos, (MARGIN_LEFT+345,MARGIN_TOP))

# Boutons d'interaction
bouton_suivant = large_font.render("SUIVANT", True, WHITE)
bouton_suivant_rect = bouton_suivant.get_rect()
bouton_auto = large_font.render("AUTO", True, GRAY)
bouton_auto_rect = bouton_auto.get_rect()
 
# Placement du texte
bouton_suivant_rect.center = (280, 500)
bouton_auto_rect.center = (520, 500)

# Affichge des boutons
screen.blit(bouton_suivant, bouton_suivant_rect)
screen.blit(bouton_auto, bouton_auto_rect)




pygame.display.update()

for event in pygame.event.get():
	a=2


# Pour comparer la valeur de deux cartes
def comparer(carte1,carte2):
	# Si la premiere carte a une valeur superieure a la seconde
	if carte1.valeur_numerique > carte2.valeur_numerique :
		return 1
	# Si la deuxieme carte a une valeur superieure a la premiere
	elif carte2.valeur_numerique > carte1.valeur_numerique :
		return 2
	# Si elles sont egales (ont la meme valeur)
	return 0

# Pour ajouter des cartes a un paquet
def ajouter_a_paquet(paquet,cartes):
	paquet += cartes

# Pour tirer une carte dans chaque paquet
def tirer_cartes(paquet1,paquet2):
	# Si le premier paquet est vide
	if len(paquet1) == 0 :
		return paquet2.pop(0),paquet2.pop(0) # On pioche une carte dans le paquet du second joueur
	# Si le deuxieme paquet est vide
	elif len(paquet2) == 0 : 
		return paquet1.pop(0),paquet1.pop(0) # On pioche une carte dans le paquet du premier joueur
	return paquet1.pop(0),paquet2.pop(0)

# Fonction qui permet de faire une manche (chaque joueur tire une carte jusqu'a ce que l'un deux gagne)
def tour(paquet1,paquet2,cartes,auto=False):
	# On recupere les cartes que chaque joueur tire
	cartes += tirer_cartes(paquet1,paquet2)
	nouvelles_cartes(cartes[-2],cartes[-1],True)
	if len(paquet1) == 1 :
		derniere_carte(True)
	elif len(paquet2) == 2 :
		derniere_carte(False)

	if not auto :
			auto = attente_clic()
	# On compare les cartes pour trouver le gagnant de la manche
	gagnant = comparer(cartes[-2],cartes[-1])
	
	# Si le joueur 1 a la meilleure carte
	if gagnant == 1 :
		ajouter_a_paquet(paquet1,cartes) # On ajoute les cartes de la manche au paquet du joueur 1
		cartes_gagnantes(cartes,True)
	# Si le joueur 2 a la meilleure carte
	elif gagnant == 2 :
		ajouter_a_paquet(paquet2,cartes) # On ajoute les cartes de la manche au paquet du joueur 2
		cartes_gagnantes(cartes,False)
	else : # Si les deux joueurs ont une carte de la meme valeur
		cartes += tirer_cartes(paquet1,paquet2) # On tire une carte face cachee
		nouvelles_cartes(cartes[-2],cartes[-1],False)
		return tour(paquet1,paquet2,cartes) # On reitere
	return auto

# Fonction qui permet de simuler une partie entiere
def partie(paquet1,paquet2) :
	auto = False
	# On compte le nombre de manches
	i = 0
	# On compte le nombre de cartes que possede chaque joueur a chaque manche (pour les graphiques de fin)
	data = [[26],[26]]
	# Tant qu'aucun des joueurs n'a plus de cartes
	while (len(paquet1) > 0 and len(paquet2) > 0):
		# On augmente le nombre de manches de 1
		i += 1
		# Puisqu'il s'agit d'une nouvelle manche, il n'y a pas de carte au milieu de la table
		cartes = []
		# On lance le tour/la manche
		auto = tour(paquet1,paquet2,cartes,auto)
		# On ajoute la taille du paquet du joueur 1 aux donnees
		data[0].append(len(paquet1))
		# On ajoute la taille du paquet du joueur 2 aux donnees
		data[1].append(len(paquet2))
		# Peut-on avoir une partie infinie ?
		if (i > 10000):
			print("melange")
			# On melange les paquets de chaque joueur
			paquet1 = pqt.melanger_paquet(paquet1)
			paquet2 = pqt.melanger_paquet(paquet2)
			# On reinitialise le compteur de manches
			i = 0
	# Si le joueur 1 n'a plus de carte
	if len(paquet1) == 0 :
		plus_de_carte(True)
		print("Le gagnant est le joueur 2")
	else : # Si le joueur 2 n'a plus de carte
		plus_de_carte(False)
		print("Le gagnant est le joueur 1")
	# On renvoie les donnees enregistrees
	return data

# Fonction qui permet d'initialiser et de lancer une partie
def lancer_partie():
	# On cree un paquet de cartes
	paquet = pqt.creer_cartes()
	# On melange le paquet
	paquet = pqt.melanger_paquet(paquet)
	# On distribue le paquet
	paquet1,paquet2 = pqt.distribuer(paquet)
	# On appelle la fonction qui permet de simuler une partie en donnant les paquets des deux joueurs en argument
	return partie(paquet1,paquet2)


def carte_visuel(carte) :
	chemin = "./img/cartes/"+carte.valeur_pratique+"_"+carte.couleur+".png"
	carte_vis = pygame.image.load(chemin)
	carte_vis = pygame.transform.scale(carte_vis , (100,160))
	return carte_vis

def nouvelles_cartes(carte1,carte2,visible) :
	if visible :
		j1 = carte_visuel(carte1)
		j2 = carte_visuel(carte2)
	else :
		j1 = dos
		j2 = dos

	for i in range(10,170,10):
		pygame.draw.rect(screen, "#035D0C",(MARGIN_LEFT,MARGIN_TOP,MARGIN_LEFT+180,MARGIN_TOP+160))
		screen.blit(j1, (MARGIN_LEFT -100 + i,MARGIN_TOP))
		screen.blit(dos, (MARGIN_LEFT-100,MARGIN_TOP))
		screen.blit(j2, (MARGIN_LEFT+340 - i,MARGIN_TOP))
		screen.blit(dos, (MARGIN_LEFT+340,MARGIN_TOP))
		pygame.display.update()

	# screen.blit(j1, (MARGIN_LEFT+60,MARGIN_TOP))
	screen.blit(j2, (MARGIN_LEFT+180, MARGIN_TOP))
	pygame.display.update()
	time.sleep(TMP_ATT)


def cartes_gagnantes(cartes,j1):
	if j1 :
		for i in range(10,170,10):
			pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT,MARGIN_TOP,MARGIN_LEFT+60,MARGIN_TOP+160))
			screen.blit(carte_visuel(cartes[-2]), (MARGIN_LEFT+60 - i,MARGIN_TOP))
			screen.blit(dos, (MARGIN_LEFT-100,MARGIN_TOP))
			pygame.display.update()
		for i in range(10,290,10):
			pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT,MARGIN_TOP,MARGIN_LEFT+60,MARGIN_TOP+160))
			screen.blit(carte_visuel(cartes[-1]), (MARGIN_LEFT+180 - i,MARGIN_TOP))
			screen.blit(dos, (MARGIN_LEFT-100,MARGIN_TOP))
			pygame.display.update()
	else :
		for i in range(10,290,10):
			pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT,MARGIN_TOP,MARGIN_LEFT+180,MARGIN_TOP+160))
			screen.blit(carte_visuel(cartes[-1]), (MARGIN_LEFT+60 + i,MARGIN_TOP))
			screen.blit(dos, (MARGIN_LEFT+340,MARGIN_TOP))
			pygame.display.update()
		for i in range(10,170,10):
			pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT,MARGIN_TOP,MARGIN_LEFT+180,MARGIN_TOP+160))
			screen.blit(carte_visuel(cartes[-2]), (MARGIN_LEFT+180 + i,MARGIN_TOP))
			screen.blit(dos, (MARGIN_LEFT+340,MARGIN_TOP))
			pygame.display.update()
	time.sleep(TMP_ATT)


def derniere_carte(j1) :
	if j1 :
		pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT-110,MARGIN_TOP,MARGIN_LEFT+180,MARGIN_TOP+160))
		screen.blit(dos, (MARGIN_LEFT-105,MARGIN_TOP))
	else :
		pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT,MARGIN_TOP,MARGIN_LEFT+280,MARGIN_TOP+160))
		screen.blit(dos, (MARGIN_LEFT+345,MARGIN_TOP))
	pygame.display.update()

def plus_de_carte(j1) :
	if j1 :
		pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT-110,MARGIN_TOP,MARGIN_LEFT+180,MARGIN_TOP+160))
	else :
		pygame.draw.rect(screen, (3,93,12),(MARGIN_LEFT,MARGIN_TOP,MARGIN_LEFT+280,MARGIN_TOP+160))
	pygame.display.update()

def attente_clic() :
	auto = False
	clic = False
	while not clic :
		mouse = pygame.mouse.get_pos()
		for event in pygame.event.get() :
			if event.type == pygame.MOUSEBUTTONDOWN:
				# Bouton suivant
				if 200 <= mouse[0] <= 200+170 and 470 <= mouse[1] <= 470+60: 
					clic = True        
                # Bouton auto
				elif 460 <= mouse[0] <= 460+120 and 470 <= mouse[1] <= 470+60:
					auto = True
					pygame.draw.rect(screen,(3,93,12),(460,470,120,60))
					pygame.draw.rect(screen,(3,93,12),(200,470,170,60))    
					pygame.display.update()
					clic = True
	return auto








