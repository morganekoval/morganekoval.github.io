import numpy as np
import matplotlib.pyplot as plt

def graph1(results):
	fig,ax = plt.subplots()
	ax.stackplot(range(len(results[0])),np.vstack(results),labels=["Joueur 1","Joueur 2"])
	plt.axhline(y = 26, color = 'r', linestyle = '-')
	ax.set_title("Evolution du paquet des joueurs")
	ax.set_ylim(0,52)
	ax.set_xlim(0,len(results[0])-1)
	ax.legend()
	plt.show()

def graph1_v2(results):
	fig,ax = plt.subplots()
	if len(results[0]) > 10000 :
		taille = len(results[0])- 5000
		results = [results[0][taille:],results[1][taille:]]
	ax.stackplot(range(len(results[0])),np.vstack(results),labels=["Joueur 1","Joueur 2"])
	plt.axhline(y = 26, color = 'r', linestyle = '-')
	ax.set_title("Evolution du paquet des joueurs")
	ax.set_ylim(0,52)
	ax.set_xlim(0,len(results[0])-1)
	ax.legend()
	plt.show()


def graph2(results):
	fig,ax = plt.subplots()
	labels = ['Joueur 1', 'Joueur 2']
	x_pos = np.arange(len(labels))
	plt.bar(x_pos, results, color=['orange', 'green'])
	plt.xticks(x_pos, labels)

	ax.set_title("Répartition des victoires")
	ax.set_ylabel('Nombre de parties gagnées')
	plt.show()




