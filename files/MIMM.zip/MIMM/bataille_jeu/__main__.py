import bataille_jeu.partie as partie
import bataille_jeu.graphs.graphs as gr
# import bataille_jeu.cartes.visuel as vis



if __name__ == '__main__':


	########################
	######## PAQUET
	########################

	## Question 1 sur le paquet
	paquet = partie.pqt.creer_cartes()
	print("Voici les cartes du paquet :")
	partie.pqt.afficher_cartes(paquet)

	## Question 2 sur le paquet
	# paquet = partie.pqt.melanger_paquet(paquet)
	# paquet1,paquet2 = partie.pqt.distribuer(paquet)
	# print("Voici les cartes du paquet du joueur 1 :")
	# partie.pqt.afficher_cartes(paquet1)



	########################
	######## STATS
	########################

	## Question 1 sur les statistiques
	# repartition,gagnant = partie.lancer_partie()
	# gr.graph1([,])

	## Question 2 sur les statistiques
	# for i in range(1):
	# 	data,gagnant = partie.lancer_partie()
	# 	res[gagnant-1] += 1
	# gr.graph1_v2(data)
















