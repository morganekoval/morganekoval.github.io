import bataille_jeu.cartes.paquet as pqt

# Pour comparer la valeur de deux cartes
def comparer(carte1,carte2):
	# Si la premiere carte a une valeur superieure a la seconde
	if carte1.valeur_numerique > carte2.valeur_numerique :
		return 1
	# Si la deuxieme carte a une valeur superieure a la premiere
	elif carte2.valeur_numerique > carte1.valeur_numerique :
		return 2
	# Si elles sont egales (ont la meme valeur)
	return 2

# Pour ajouter des cartes a un paquet
def ajouter_a_paquet(paquet,cartes):
	paquet += cartes

# Pour tirer une carte dans chaque paquet
def tirer_cartes(paquet1,paquet2):
	# Si le premier paquet est vide
	if len(paquet1) == 0 :
		return paquet2.pop(0),paquet2.pop(0) # On pioche une carte dans le paquet du second joueur
	# Si le deuxieme paquet est vide
	elif len(paquet2) == 0 : 
		return paquet1.pop(0),paquet1.pop(0) # On pioche une carte dans le paquet du premier joueur
	return paquet1.pop(0),paquet2.pop(0)

# Fonction qui permet de faire une manche (chaque joueur tire une carte jusqu'a ce que l'un deux gagne)
def tour(paquet1,paquet2,cartes):
	# On recupere les cartes que chaque joueur tire
	cartes += tirer_cartes(paquet1,paquet2)
	# On compare les cartes pour trouver le gagnant de la manche
	gagnant = comparer(cartes[-2],cartes[-1])
	
	# Si le joueur 1 a la meilleure carte
	if gagnant == 1 :
		ajouter_a_paquet(paquet1,cartes) # On ajoute les cartes de la manche au paquet du joueur 1
	# Si le joueur 2 a la meilleure carte
	elif gagnant == 2 :
		ajouter_a_paquet(paquet2,cartes) # On ajoute les cartes de la manche au paquet du joueur 2
	else : # Si les deux joueurs ont une carte de la meme valeur
		cartes += tirer_cartes(paquet1,paquet2) # On tire une carte face cachee
		tour(paquet1,paquet2,cartes) # On reitere

# Fonction qui permet de simuler une partie entiere
def partie(paquet1,paquet2) :
	# On compte le nombre de manches
	i = 0
	# On compte le nombre de cartes que possede chaque joueur a chaque manche (pour les graphiques de fin)
	data = [[26],[26]]
	# Tant qu'aucun des joueurs n'a plus de cartes
	while (len(paquet1) > 0 and len(paquet2) > 0):
		# On augmente le nombre de manches de 1
		i += 1
		# Puisqu'il s'agit d'une nouvelle manche, il n'y a pas de carte au milieu de la table
		cartes = []
		# On lance le tour/la manche
		tour(paquet1,paquet2,cartes)
		# On ajoute la taille du paquet du joueur 1 aux donnees
		data[0].append(len(paquet1))
		# On ajoute la taille du paquet du joueur 2 aux donnees
		data[1].append(len(paquet2))
		# Peut-on avoir une partie infinie ?
		if (i > 10000):
			print("melange")
			# On melange les paquets de chaque joueur
			paquet1 = pqt.melanger_paquet(paquet1)
			paquet2 = pqt.melanger_paquet(paquet2)
			# On reinitialise le compteur de manches
			i = 0
	# Si le joueur 1 n'a plus de carte
	if len(paquet1) == 0 :
		print("Le gagnant est le joueur 1")
		return data,2
	else : # Si le joueur 2 n'a plus de carte
		print("Le gagnant est le joueur 2")
		return data,1

# Fonction qui permet d'initialiser et de lancer une partie
def lancer_partie():
	# On cree un paquet de cartes
	paquet = pqt.creer_cartes()
	# On melange le paquet
	paquet = pqt.melanger_paquet(paquet)
	# On distribue le paquet
	paquet1,paquet2 = pqt.distribuer(paquet)
	# On appelle la fonction qui permet de simuler une partie en donnant les paquets des deux joueurs en argument
	return partie(paquet1,paquet2)


